from fastapi import FastAPI
from scraper import wtwd, wtd, tireco
from shopify_sync import create_or_update_product

app = FastAPI()

@app.get("/search")
def search(width: str, aspect: str, diameter: str):
    size = f"{width}{aspect}{diameter}"
    results = []

    for scraper in [wtwd, wtd, tireco]:
        try:
            tires = scraper.search_tires(size)
            for t in tires:
                sync = create_or_update_product(t)
                results.append({"scraper": scraper.__name__, "tire": t, "shopifySync": sync})
        except Exception as e:
            results.append({"scraper": scraper.__name__, "error": str(e)})
    
    return {"size": size, "results": results}
