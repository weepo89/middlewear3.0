import requests
import os

SHOPIFY_STORE = os.getenv("SHOPIFY_STORE")
SHOPIFY_ACCESS_TOKEN = os.getenv("SHOPIFY_ACCESS_TOKEN")

headers = {
    "Content-Type": "application/json",
    "X-Shopify-Access-Token": SHOPIFY_ACCESS_TOKEN
}

ALL_TIRES_COLLECTION_TITLE = "All Tires"
PERFORMANCE_COLLECTION_TITLE = "Performance Tires"
PERFORMANCE_PRICE_THRESHOLD = 200


def create_or_update_product(product):
    try:
        title = f"{product['brand']} {product['model']}"
        existing = find_product_by_title(title)

        # Build tags for filtering
        tags = []
        try:
            parts = product["size"].replace(" ", "").split("/")
            if len(parts) == 2:
                width = parts[0]
                aspect_diam = parts[1]
                if len(aspect_diam) > 2:
                    aspect, diameter = aspect_diam[:2], aspect_diam[2:]
                    tags = [f"Width:{width}", f"Aspect:{aspect}", f"Diameter:{diameter}"]
                else:
                    tags = [f"Size:{product['size']}"]
            else:
                tags = [f"Size:{product['size']}"]
        except:
            tags = [f"Size:{product['size']}"]

        variant = {
            "option1": product["size"],
            "price": str(product["price"]),
            "inventory_quantity": int(product.get("stock", 0))
        }

        if existing:
            product_id = existing["id"]
            add_variant_to_product(product_id, variant, product.get("image"))
            return {"action": "variant_added", "product": title, "variant": product["size"]}

        else:
            payload = {
                "product": {
                    "title": title,
                    "body_html": f"<p>Distributor: {product['distributor']}</p>",
                    "vendor": product["distributor"],
                    "status": "active",
                    "tags": ", ".join(tags),
                    "options": ["Size"],
                    "images": [{"src": product.get("image")}],
                    "variants": [variant]
                }
            }

            url = f"https://{SHOPIFY_STORE}/admin/api/2025-01/products.json"
            res = requests.post(url, headers=headers, json=payload)
            data = res.json()

            if res.status_code == 201:
                product_id = data["product"]["id"]

                # Always drop into All Tires
                all_tires_id = ensure_collection(ALL_TIRES_COLLECTION_TITLE)
                if all_tires_id:
                    add_to_collection(product_id, all_tires_id)

                # Performance Tires if price high or brand matches
                price = float(product.get("price", 0))
                perf_brands = ["Michelin", "Pirelli", "Continental", "Goodyear", "Bridgestone", "Toyo", "Nitto"]
                if price >= PERFORMANCE_PRICE_THRESHOLD or any(b in title for b in perf_brands):
                    perf_id = ensure_collection(PERFORMANCE_COLLECTION_TITLE)
                    if perf_id:
                        add_to_collection(product_id, perf_id)

                return {"action": "product_created", "product": title, "variant": product["size"], "response": data}
            else:
                return {"error": res.text, "product": title}
    except Exception as e:
        return {"error": str(e), "product": product}


def find_product_by_title(title):
    try:
        url = f"https://{SHOPIFY_STORE}/admin/api/2025-01/products.json?title={title}"
        res = requests.get(url, headers=headers)
        data = res.json()
        if "products" in data and len(data["products"]) > 0:
            return data["products"][0]
        return None
    except:
        return None


def add_variant_to_product(product_id, variant, image_url=None):
    try:
        url = f"https://{SHOPIFY_STORE}/admin/api/2025-01/products/{product_id}/variants.json"
        res = requests.post(url, headers=headers, json={"variant": variant})
        data = res.json()
        if image_url and "variant" in data:
            image_url_post = f"https://{SHOPIFY_STORE}/admin/api/2025-01/products/{product_id}/images.json"
            requests.post(image_url_post, headers=headers, json={"image": {"src": image_url, "variant_ids": [data["variant"]["id"]]}})
        return data
    except Exception as e:
        return {"error": str(e)}


def ensure_collection(title):
    try:
        url = f"https://{SHOPIFY_STORE}/admin/api/2025-01/custom_collections.json?title={title}"
        res = requests.get(url, headers=headers)
        data = res.json()
        if "custom_collections" in data and len(data["custom_collections"]) > 0:
            return data["custom_collections"][0]["id"]

        # Create collection if not found
        create_url = f"https://{SHOPIFY_STORE}/admin/api/2025-01/custom_collections.json"
        payload = {"custom_collection": {"title": title, "published": True}}
        res = requests.post(create_url, headers=headers, json=payload)
        data = res.json()
        if "custom_collection" in data:
            return data["custom_collection"]["id"]
        return None
    except Exception as e:
        return None


def add_to_collection(product_id, collection_id):
    try:
        collect_url = f"https://{SHOPIFY_STORE}/admin/api/2025-01/collects.json"
        requests.post(collect_url, headers=headers, json={
            "collect": {"product_id": product_id, "collection_id": collection_id}
        })
    except:
        pass
