def search_tires(size: str):
    return [{
        "distributor": "DemoDistributor",
        "brand": "DemoBrand",
        "model": "DemoModel",
        "size": size,
        "stock": "10",
        "price": "100.00",
        "image": "https://via.placeholder.com/300x300.png?text=Tire"
    }]
